DSA - CS2233 - coding assignment -2 

1. printing traversals from given tree - non recursively
how to run :
g++ traversals.cpp -o traversals
./traversals
input format :  as given in the question

2. inorder and preorder to give the level order traversal
how to run:
g++ buildTree.cpp -o buildTree
./buildTree
input format : as given in the question

3. most frequent pair distance in a given BST 
how to run :
g++ mostFrequentDistance.cpp -o mostFrequentDistance 
./mostFrequentDistance
input format : as givn in the question

4. longest equal valued path in a BST 
how to run:
g++ largestEqualValPath -o largestEqualValPath
./largestEqualValPath
input format : as given  in the question

5. k-th node on the path in a given BST , between 2 given elements
how to run: 
g++ kthinPath.cpp -o kthinPath
./kthinPath
input format : as given in the questin

6. range sum  : sum of elements in a given range of elts in the BST
how to run :
g++ rangeSum.cpp -o rangeSum
./rangeSum
input format : as given in the question
